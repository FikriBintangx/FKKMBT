-- Check kegiatan table structure and data
SELECT id, judul, foto, tanggal, deskripsi FROM kegiatan LIMIT 5;

-- If foto column is empty, let's update with a placeholder or check if we need to add sample images
-- For now, let's see what's in the database
